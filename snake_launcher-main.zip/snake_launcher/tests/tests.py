# localDB_test.py

import unittest
from localDB import db_utils


class TestDbutils(unittest.TestCase):

    def test_add_or_update(self):
        db_utils.add_or_update_server_config(None,"testconfig", "https://test.url.org", "123456789xyz",
                                             "https://192.168.0.0/tool_list.txt")
        self.assertIsNone(db_utils.get_server_config(None))


if __name__ == '__main__':
    unittest.main()
