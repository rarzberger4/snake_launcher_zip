# snake_launcher

snake_launcher makes it easy to deploy programs directly to the end user. There is no requirement to what is deployed,
it could simply be python code or a .exe or just a link. By using the launcher folder and the
install.py/uninstall.py/run.py scripts nearly everything can be deployed with ease.

## Architecture

- Gitea Server
    - hosting a toolbox.txt with a list of all repos to be shown inside the snake launcher
    - hosting the repos mentioned in the toolbox.txt
- inside every repo to be deployed a folder in the root directory named "snake_launcher"
    - inside this folder there need to be a install.py/uninstall.py/run.py with code to be run for various tasks.
      Important - the return code of those scripts is checked by the snake_launcher to determine the success of a
      scripts task
- snake_launcher
    - installed on the end users machine

Gitea is hosting the code or the files that need to be deployed on the end user machine. snake_launcher looks for the
repos configured and checks for newer versions available. Then offers the user to install/update/uninstall the programs
in those repos.

## Setup

1. Get a gitea server up and running (https://about.gitea.com/)
2. deploy the toolbox.txt in a special repo only containing this text file
3. deploy all repos you want to have available in the snake_launcher and add the link to the toolbox.txt
4. create an authorization token in gitea with access to all necessary repos
5. Deploy the snake_launcher to the end user
    - both using the python code itself is possible or by wrapping the code into an installer.exe with all dependencies
      already delivered
6. Configure the server settings inside the snake_launcher
    - Multiple server may be configured inside the settings
7. You are ready to go