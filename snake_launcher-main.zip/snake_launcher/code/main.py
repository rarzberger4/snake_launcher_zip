import tkinter as tk
from gui import gui
from localDB import db_utils

if __name__ == "__main__":
    db_utils.update_repo_info()
    root = tk.Tk()  # Initialize GUI window
    gui.setup(root)


