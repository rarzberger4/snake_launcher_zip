import tkinter as tk
from tkinter import messagebox, ttk
from localDB import db_utils
from gui import gui

"""module for editing the server config including the gui"""

server_config_window = None


class ServerConfigDialog(tk.Toplevel):
    def __init__(self, parent, config_name="", api_url="", token="", tool_list="", title=None):
        super().__init__(parent)
        self.tool_list_entry = None
        self.token_entry = None
        self.api_url_entry = None
        self.name_entry = None
        self.result = None
        self.transient(parent)  # Make the dialog a transient window of the main window
        self.title(title or "Server Configuration")

        # Directly use parameters
        self.config_name = config_name
        self.api_url = api_url
        self.token = token
        self.tool_list = tool_list

        body = tk.Frame(self)
        self.body(body)  # Create the body which now uses class attributes
        body.pack(padx=5, pady=5)

        self.buttonbox()
        self.grab_set()  # Modal focus
        self.protocol("WM_DELETE_WINDOW", self.cancel)  # Handle close button
        self.geometry("+{}+{}".format(parent.winfo_rootx() + 50, parent.winfo_rooty() + 50))
        self.wait_window(self)  # Wait here until the window is closed

    def body(self, master):
        # Create and place labels and entry fields
        tk.Label(master, text="Name:").grid(row=0)
        tk.Label(master, text="API URL:").grid(row=1)
        tk.Label(master, text="Token:").grid(row=2)
        tk.Label(master, text="Tool List URL:").grid(row=3)

        # Entry widgets for the data
        self.name_entry = tk.Entry(master)
        self.api_url_entry = tk.Entry(master)
        self.token_entry = tk.Entry(master)
        self.tool_list_entry = tk.Entry(master)

        # Insert existing data into entries
        self.name_entry.insert(0, self.config_name)
        self.api_url_entry.insert(0, self.api_url)
        self.token_entry.insert(0, self.token)
        self.tool_list_entry.insert(0, self.tool_list)

        # Grid placement
        self.name_entry.grid(row=0, column=1)
        self.api_url_entry.grid(row=1, column=1)
        self.token_entry.grid(row=2, column=1)
        self.tool_list_entry.grid(row=3, column=1)

        return self.name_entry  # Set initial focus

    def buttonbox(self):
        # Add standard button box with OK and Cancel
        box = tk.Frame(self)
        ok_button = tk.Button(box, text="OK", width=10, command=self.ok, default=tk.ACTIVE)
        ok_button.pack(side=tk.LEFT, padx=5, pady=5)
        cancel_button = tk.Button(box, text="Cancel", width=10, command=self.cancel)
        cancel_button.pack(side=tk.LEFT, padx=5, pady=5)
        box.pack()

    def ok(self):
        # Process data and close
        self.result = {
            "config_name": self.name_entry.get(),
            "api_url": self.api_url_entry.get(),
            "token": self.token_entry.get(),
            "tool_list": self.tool_list_entry.get()
        }
        self.withdraw()
        self.update_idletasks()
        self.destroy()

    def cancel(self):
        # Close the dialog without saving
        self.result = None
        self.destroy()


def refresh_config_list(tree):
    tree.delete(*tree.get_children())  # Clear existing entries
    data = db_utils.get_all_server_configs()
    for server in data:
        # Here we assume that `server` has a `uid` attribute and others for display
        tree.insert("", 'end', values=(server.name, server.last_updated), iid=server.uid)


def delete_config(tree):
    selected_item = tree.selection()
    if selected_item:
        uid = selected_item[0]
        config_name = tree.item(selected_item)['values'][0]
        db_utils.delete_server_config(uid)
        refresh_config_list(tree)
        messagebox.showinfo("Success", f"Configuration for '{config_name}' deleted.")


def add_config(tree, root):
    dialog = ServerConfigDialog(root)
    if dialog.result:
        db_utils.add_or_update_server_config(**dialog.result)
        refresh_config_list(tree)
        messagebox.showinfo("Success", f"Configuration for '{dialog.result['config_name']}' added/updated.")


def edit_config(tree, root):
    selected_item = tree.selection()
    if not selected_item:
        messagebox.showinfo("Error", "Please select a configuration item.")
        return

    uid = selected_item[0]
    print(selected_item)
    print(uid)

    config = db_utils.get_server_config(uid)
    if config:
        dialog = ServerConfigDialog(root, config_name=config.name, api_url=config.api_url, token=config.token,
                                    tool_list=config.tool_list,
                                    title="Edit Server Configuration")
        if dialog.result:
            db_utils.add_or_update_server_config(uid, **dialog.result)
            refresh_config_list(tree)
            messagebox.showinfo("Success", "Configuration updated successfully.")
    else:
        messagebox.showinfo("Error", "Configuration data not found.")


def on_closing():
    global server_config_window
    server_config_window.destroy()
    server_config_window = None


def setup_server_config():
    global server_config_window

    if server_config_window is not None and tk.Toplevel.winfo_exists(server_config_window):
        server_config_window.lift()
        return

    server_config_window = tk.Toplevel()
    server_config_window.iconbitmap(gui.ICON_FILE)
    server_config_window.title("Server Configuration")

    # Ensure the window is destroyed when closed
    server_config_window.protocol("WM_DELETE_WINDOW", on_closing)

    # TreeView to display server configurations
    tree = ttk.Treeview(server_config_window, columns=('Name', 'Last Updated'), show='headings')
    tree.heading('Name', text='Name')
    tree.heading('Last Updated', text='Last Updated')
    tree.column('Name', width=150)
    tree.column('Last Updated', width=150)
    tree.pack(expand=True, fill='both', padx=20, pady=20)

    # Frame for buttons
    button_frame = tk.Frame(server_config_window)
    button_frame.pack(padx=10, pady=10, fill=tk.X)

    # Button to delete a configuration
    delete_button = tk.Button(button_frame, text="Delete Configuration", command=lambda: delete_config(tree))
    delete_button.grid(row=0, column=2, padx=5, pady=5, sticky='ew')

    # Button to add a new configuration
    add_button = tk.Button(button_frame, text="Add", command=lambda: add_config(tree, server_config_window))
    add_button.grid(row=0, column=0, padx=5, pady=5, sticky='ew')

    # Button to change an existing configuration
    add_button = tk.Button(button_frame, text="Edit", command=lambda: edit_config(tree, server_config_window))
    add_button.grid(row=0, column=1, padx=5, pady=5, sticky='ew')

    # Configure the column weights to ensure buttons expand equally
    button_frame.grid_columnconfigure(0, weight=1)
    button_frame.grid_columnconfigure(1, weight=1)
    button_frame.grid_columnconfigure(2, weight=1)

    refresh_config_list(tree)
    # Start the GUI
    server_config_window.mainloop()
