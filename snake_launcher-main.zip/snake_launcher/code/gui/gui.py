import os
import tkinter as tk
import threading
from repo_utils import run_app_py_scripts
from tkinter import ttk, scrolledtext, messagebox
from localDB import db_utils
from gui import server_config
from auto_update import auto_settings_page

ICON_FILE = 'resources/snake_launcher_icon.ico'

"""main gui module"""


def setup_styles():
    """Set up the custom styles for the GUI components."""
    style = ttk.Style()
    style.configure("RepoFrame.TFrame", background="#f0f0f0", relief="groove", borderwidth=2)
    style.configure("RepoLabel.TLabel", background="#f0f0f0", font=('Helvetica', 12))
    style.configure("RepoButton.TButton", font=('Helvetica', 12, 'bold'), borderwidth=1)
    style.configure("ToggleButton.TCheckbutton", font=('Helvetica', 12), background="#f0f0f0")


def add_repo_frame(container, repo_details):
    """Create and add a frame for each repository with details and action buttons."""
    frame = ttk.Frame(container, style="RepoFrame.TFrame", padding="3 3 12 12")
    frame.pack(fill=tk.X, expand=True, padx=10, pady=5)

    frame.repo_url = ttk.Label(frame, text=get_reponame(repo_details['repo']['repo_url']), style="RepoLabel.TLabel")
    frame.pre_release_var = tk.BooleanVar(value=False)
    frame.install_update_btn = ttk.Button(frame, text="Install", style="Action.TButton")
    frame.installed_version = ttk.Label(frame, text="installed: None", style="RepoLabel.TLabel")
    frame.latest_stable = ttk.Label(frame, text="stable: N/A", style="RepoLabel.TLabel")
    frame.latest_prerelease = ttk.Label(frame, text="pre release: N/A", style="RepoLabel.TLabel")
    frame.toggle_prerelease = ttk.Checkbutton(frame, text="Pre-release", variable=frame.pre_release_var,
                                              style="ToggleButton.TCheckbutton")
    frame.run_btn = ttk.Button(frame, text="Run", style="Action.TButton")
    frame.uninstall_btn = ttk.Button(frame, text="Uninstall", style="Action.TButton")

    # Configuring the grid layout within the frame to allocate space properly
    frame.columnconfigure(0, weight=1)  # Main information stretches
    frame.columnconfigure(1, weight=0)  # Version info
    frame.columnconfigure(2, weight=0)  # Stable version
    frame.columnconfigure(3, weight=0)  # Pre-release version
    frame.columnconfigure(4, weight=0)  # Toggle button
    frame.columnconfigure(5, weight=0)  # Install button
    frame.columnconfigure(6, weight=0)  # Run button
    frame.columnconfigure(7, weight=0)  # Uninstall button

    # Placing elements in the grid
    frame.repo_url.grid(row=0, column=0, sticky=(tk.W, tk.E))
    frame.installed_version.grid(row=0, column=1, sticky=tk.W)
    frame.latest_stable.grid(row=1, column=0, sticky=tk.W)
    frame.latest_prerelease.grid(row=2, column=0, sticky=tk.W)
    frame.toggle_prerelease.grid(row=0, column=4, sticky=tk.E)
    frame.install_update_btn.grid(row=0, column=5, sticky=tk.E)
    frame.run_btn.grid(row=0, column=6, sticky=tk.E)
    frame.uninstall_btn.grid(row=0, column=7, sticky=tk.E)

    # Set up the frame with the initial details
    update_repo_frame(frame, repo_details, container)
    return frame


def update_repo_frame(frame, repo_details, container):
    """Update the given frame with repository details and action buttons."""
    repo_url = repo_details['repo']['repo_url']
    frame.repo_url.config(text=get_reponame(repo_url))
    frame.install_update_btn.config(state=tk.NORMAL)

    if db_utils.get_installed_version(repo_url) is not None:
        frame.uninstall_btn.config(state=tk.NORMAL)
        if db_utils.get_pre_release(repo_url):
            frame.pre_release_var.set(True)
            if compare_versions(repo_details['repo']['latest_prerelease'],
                                db_utils.get_installed_version(repo_url)) == 1:
                frame.install_update_btn.config(text="Update", command=lambda: install_or_update_repo(repo_details,
                                                                                                      frame.pre_release_var.get(),
                                                                                                      frame, container))
            else:
                frame.install_update_btn.config(text="Up-to-date", state=tk.DISABLED)
        else:
            frame.pre_release_var.set(False)
            if compare_versions(repo_details['repo']['latest_stable'], db_utils.get_installed_version(repo_url)) == 1:
                frame.install_update_btn.config(text="Update", command=lambda: install_or_update_repo(repo_details,
                                                                                                      frame.pre_release_var.get(),
                                                                                                      frame, container))
            else:
                frame.install_update_btn.config(text="Up-to-date", state=tk.DISABLED)
        frame.installed_version.config(text="installed: " + (db_utils.get_installed_version(repo_url) or "None"))
    else:
        frame.uninstall_btn.config(state=tk.DISABLED)
        frame.installed_version.config(text="installed: None")
        frame.pre_release_var.set(False)
        frame.install_update_btn.config(text="Install", command=lambda: install_or_update_repo(repo_details,
                                                                                               frame.pre_release_var.get(),
                                                                                               frame, container))

    frame.latest_stable.config(text="stable: " + (repo_details['repo']['latest_stable'] or "N/A"))
    frame.latest_prerelease.config(text="pre release: " + (repo_details['repo']['latest_prerelease'] or "N/A"))

    frame.run_btn.config(command=lambda: run_repo(repo_details, db_utils.get_installed_version(repo_url)))
    frame.uninstall_btn.config(
        command=lambda: uninstall_repo(repo_details, db_utils.get_installed_version(repo_url), frame, container))


def get_reponame(repo_info):
    return repo_info.split('/')[4].split('.')[0]


def install_or_update_repo(repo, use_prerelease, frame, container):
    """installing or updating a given repo wihtin a extra thread to keep gui responsive"""

    # Static label to indicate the process has started
    progress_label = ttk.Label(frame, text="In Progress...", style="RepoLabel.TLabel")
    progress_label.grid(row=3, column=0, sticky=tk.W, columnspan=8)

    # Progress bar to show ongoing activity
    progress_bar = ttk.Progressbar(frame, mode='indeterminate')
    progress_bar.grid(row=4, column=0, sticky=tk.W, columnspan=8)
    progress_bar.start()

    def update_task():
        try:
            if use_prerelease:
                if repo['repo']['latest_prerelease'] != db_utils.get_installed_version(repo['repo']['repo_url']):
                    if run_app_py_scripts.install(repo, repo['repo']['latest_prerelease']):
                        frame.after(50, lambda: refresh_repo_frames(container))
                    else:
                        frame.after(50, lambda: messagebox.showinfo("Error", "Installation failed"))
                else:
                    frame.after(50, lambda: messagebox.showinfo("Info", "No installation available"))
            else:
                if repo['repo']['latest_stable'] != db_utils.get_installed_version(repo['repo']['repo_url']):
                    if run_app_py_scripts.install(repo, repo['repo']['latest_stable']):
                        frame.after(50, lambda: refresh_repo_frames(container))
                    else:
                        frame.after(50, lambda: messagebox.showinfo("Error", "Installation failed"))
                else:
                    frame.after(50, lambda: messagebox.showinfo("Info", "No installation available"))
        finally:
            frame.after(50, progress_label.destroy)
            frame.after(50, progress_bar.stop)
            frame.after(50, progress_bar.destroy)

    update_thread = threading.Thread(target=update_task)
    update_thread.start()


def run_repo(repo_details, version):
    """Run the program provided by the repository."""

    if version is None:
        messagebox.showinfo("Starting Tool",
                            f"Currently there is no version of tool {repo_details['repo']['repo_name']} installed.")
    else:
        print(f"Starting {repo_details['repo']['repo_name']}")
        run_app_py_scripts.run(repo_details['repo']['repo_name'] + '_' + version)


def compare_versions(version1, version2):
    """
    Compare two semantic versions given.
    Returns 1 if version1 is higher, -1 if version2 is higher, and 0 if they are equal.
    """
    # Split the version strings into lists of integers
    v1_parts = list(map(int, version1.split('.')))
    v2_parts = list(map(int, version2.split('.')))

    # Pad the shorter list with zeros if versions have different lengths
    max_length = max(len(v1_parts), len(v2_parts))
    v1_parts.extend([0] * (max_length - len(v1_parts)))
    v2_parts.extend([0] * (max_length - len(v2_parts)))

    # Compare versions part by part
    for v1, v2 in zip(v1_parts, v2_parts):
        if v1 > v2:
            return 1
        elif v1 < v2:
            return -1
    return 0


def uninstall_repo(repo_details, version, frame, container):
    """Uninstall a repository, all done in a separate thread."""

    answer = messagebox.askyesno("Confirm Uninstall",
                                 f"Are you sure you want to uninstall the repository at {repo_details['repo']['repo_name']}?")
    if answer:
        # Static label to indicate the process has started
        progress_label = ttk.Label(frame, text="Uninstalling...", style="RepoLabel.TLabel")
        progress_label.grid(row=3, column=0, sticky=tk.W, columnspan=8)

        # Progress bar to show ongoing activity
        progress_bar = ttk.Progressbar(frame, mode='indeterminate')
        progress_bar.grid(row=4, column=0, sticky=tk.W, columnspan=8)
        progress_bar.start()

        def uninstall_task():
            try:
                print(f"Uninstalling {repo_details['repo']['repo_name']}")
                if run_app_py_scripts.uninstall(repo_details, version):
                    frame.after(50, lambda: messagebox.showinfo("Uninstalled", "Repository uninstalled successfully."))
                    frame.after(50, lambda: refresh_repo_frames(container))
                else:
                    frame.after(50, lambda: messagebox.showinfo("Error", "Unable to uninstall the repository."))
            finally:
                frame.after(50, progress_label.destroy)
                frame.after(50, progress_bar.stop)
                frame.after(50, progress_bar.destroy)

        uninstall_thread = threading.Thread(target=uninstall_task)
        uninstall_thread.start()


def display_data(repo_list, container, progress_bar, error=None):
    """Display the fetched data or an error message."""
    if error:
        print("Failed to fetch repo_list")
    else:
        for repo_details in repo_list:
            add_repo_frame(container, repo_details)
    progress_bar.stop()
    progress_bar.destroy()


def about():
    root = tk.Toplevel()
    root.title("Display README.md")
    # Creating a scrolled text widget
    text_widget = scrolledtext.ScrolledText(root, width=80, height=20)
    text_widget.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

    readme_path = 'README.md'  # Path to your README.md file
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as file:
            content = file.read()
            text_widget.insert(tk.END, content)
    else:
        text_widget.insert(tk.END, "README.md file not found.")


def top_menu(root):
    # Main menu bar
    main_menu = tk.Menu(root)
    root.config(menu=main_menu)

    # Settings menu
    settings_menu = tk.Menu(main_menu, tearoff=0)  # 'tearoff=0' to prevent detachable menus
    main_menu.add_cascade(label="Settings", menu=settings_menu)
    settings_menu.add_command(label="Server Settings", command=server_config.setup_server_config)
    settings_menu.add_command(label="Update Settings", command=auto_settings_page.open_update_scheduler)
    settings_menu.add_separator()  # Adding a separator line for better visual separation
    settings_menu.add_command(label="Exit", command=root.quit)

    # Help menu
    help_menu = tk.Menu(main_menu, tearoff=0)
    main_menu.add_cascade(label="Help", menu=help_menu)
    help_menu.add_command(label="About...", command=about)


def load_repos(callback, tree, progress_bar):
    """loads all repos which are behind the repo list of each server config"""
    repo_list = db_utils.get_repo_info()
    callback(repo_list, tree, progress_bar)


def refresh_repo_frames(container):
    """Refresh the repository frames by reloading the data from the JSON file."""
    repo_list = db_utils.get_repo_info()
    for frame in container.winfo_children():
        repo_url = frame.repo_url.cget("text")
        for repo_details in repo_list:
            if get_reponame(repo_details['repo']['repo_url']) == repo_url:
                update_repo_frame(frame, repo_details, container)
                break


def setup(root):
    setup_styles()
    top_menu(root)
    root.iconbitmap(ICON_FILE)
    root.title("Snake Launcher")

    if not db_utils.read_json(db_utils.SERVER_CONFIG):  # check for empty or non-readable server config
        messagebox.showinfo("Warning", "No server configuration found")
        server_config.setup_server_config()  # prompts the user to the server setup menu

    container = ttk.Frame(root)
    container.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

    progress_bar = ttk.Progressbar(root, mode='indeterminate')
    progress_bar.pack(pady=10)
    progress_bar.start(10)

    threading.Thread(target=lambda: load_repos(display_data, container, progress_bar)).start()
    root.mainloop()
