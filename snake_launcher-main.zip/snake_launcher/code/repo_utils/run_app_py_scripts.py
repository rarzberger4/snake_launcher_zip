import subprocess
import os
import sys
import shutil
from localDB import db_utils
from repo_utils import git_server


def run_app_py_scripts(program_name, script_name):
    """Execute programs' python scripts."""
    script_path = os.path.join("apps", program_name, "snake_launcher", script_name)

    if os.path.exists(script_path):
        result = subprocess.run(["python", script_path], capture_output=True, text=True)
        print(f"Python executable: {sys.executable}")
        print(result.stdout)
        print(result.stderr)
        if result.returncode == 0:
            return True
        else:
            return False
    else:
        print(f"Error: {script_path} not found!")
        return False


def remove_app_directory(program_name):
    """Remove program source folder from 'app' directory"""
    app_directory = os.path.join("apps", program_name)

    if os.path.exists(app_directory):
        shutil.rmtree(app_directory)
        print(f"The directory {app_directory} has been deleted.")
    else:
        print(f"Error: {app_directory} not found!")


def install(repo, version):
    """
    Install the specified program.
    :param program_name: Name of the program to install.
    """

    if db_utils.check_tool_installation_required(repo, version):
        another_installed_version = db_utils.get_installed_version(repo['repo']['repo_url'])

        if another_installed_version is not None:
            uninstall(repo, another_installed_version)

        print(f"Starting installing version {version} of {repo['repo']['repo_name']}")
        git_server.download_and_extract_repo(repo, version)

        if run_app_py_scripts(repo['repo']['repo_name'] + '_' + version, "install.py"):
            db_utils.add_or_update_repo_info(repo['repo'], version,
                                             db_utils.is_prerelease(repo['repo']['repo_url'], version))
            return True

    return False


def uninstall(repo, version):
    """
    Uninstall the specified program.
    :param program_name: Name of the program to uninstall.
    """

    if not (db_utils.check_tool_installation_required(repo, version)):
        print(f"Starting uninstalling version {version} of {repo['repo']['repo_name']}")
        if run_app_py_scripts(repo['repo']['repo_name'] + '_' + version, "uninstall.py"):
            remove_app_directory(repo['repo']['repo_name'] + '_' + version)
            db_utils.add_or_update_repo_info(repo['repo'], None, db_utils.is_prerelease(repo['repo']['repo_url'], version))
            return True

    return False


def run(program_name):
    """
    Run the specified program.
    :param program_name: Name of the program to uninstall.
    """
    print("Starting run.py...")
    run_app_py_scripts(program_name, "run.py")
