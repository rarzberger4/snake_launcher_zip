import os
import zipfile
import requests
import shutil

"""module offers functions to access infos from a git server"""


def make_api_request(url, authorization, **kwargs):
    """Simplified function for making API requests."""
    try:
        response = requests.get(url, headers=authorization, **kwargs)
        response.raise_for_status()
        return response
    except requests.RequestException as e:
        print(f"Error: Unable to fetch from {url}. Exception: {e}")
        return None


def get_user_name(url):
    """Get user name of git server user."""
    parts = url.rstrip('/').split("/")
    return parts[-2]


def get_repo_name(url):
    """Get repo name of git repo."""
    parts = url.rstrip('/').split("/")
    return parts[-1].replace('.git', '')


def get_latest_release(url, authorization):
    """Fetch latest release (both stable and prerelease) from the repo URL."""
    releases_data = make_api_request(url, authorization).json()

    latest_stable = next((release["tag_name"] for release in releases_data if not release["prerelease"]), None)
    latest_prerelease = next((release["tag_name"] for release in releases_data if release["prerelease"]), None)

    return {
        "latest_stable": latest_stable,
        "latest_prerelease": latest_prerelease
    }


def get_list_from_git(server):
    """Fetch repository list along with their latest releases."""
    url = server.tool_list
    authorization = dict()
    authorization["token"] = server.token
    api_url = server.api_url

    list_data = make_api_request(url, authorization).text
    if list_data:
        repo_list = [{"repo_url": entry.strip(), "version": None} for entry in list_data.strip().split('\n')]
        for repo in repo_list:
            repo_name = get_repo_name(repo['repo_url'])
            repo['repo_name'] = repo_name
            user_name = get_user_name(repo['repo_url'])
            api_url_repo = f"{api_url}/repos/{user_name}/{repo_name}/releases"

            release_data = get_latest_release(api_url_repo, authorization)
            if release_data:
                release_data['api_url_repo'] = api_url_repo
                release_data['authorization'] = authorization
                repo.update(release_data)
            
        return repo_list


def get_release_download_url(repo, version):
    """Get download URL for a specific release version."""
    api_url = repo['repo']['api_url_repo']
    authorization = repo['repo']['authorization']
    releases_data = make_api_request(api_url, authorization).json()

    return next((release["zipball_url"] for release in releases_data if release["tag_name"] == version), None)


def download_and_extract_repo(repo, version, destination_folder="apps", progress_callback=None, status_label=None):
    """Download and extract a specific release version."""
    if not os.path.exists(destination_folder):
        os.makedirs(destination_folder)
        
    tool_path = os.path.join(destination_folder, f"{repo['repo']['repo_name']}_{version}")
    check_and_delete_path(tool_path)
    check_and_delete_path(tool_path + ".zip")
    download_url = get_release_download_url(repo, version)
    if download_url:
        response = make_api_request(download_url, repo['repo']['authorization'], stream=True)
        if response:
            zip_path = tool_path + ".zip"
            total_size = int(response.headers.get('content-length', 0))

            # Download and extract the ZIP with progress updates
            download_zip(response, zip_path, total_size, progress_callback, status_label)
            extract_zip(zip_path, destination_folder, progress_callback, status_label)
            
            # Wait for the extraction process to finish
            while not any(fname.endswith(repo['repo']['repo_name']) for fname in os.listdir(destination_folder)):
                pass

            os.rename(os.path.join(destination_folder, repo['repo']['repo_name']), tool_path)
            os.remove(zip_path)


def download_zip(response, zip_path, total_size, progress_callback, status_label):
    """Download ZIP file with progress updates."""
    block_size = 8192  # 8K
    wrote = 0
    if status_label:
        status_label("Downloading...")
    with open(zip_path, 'wb') as f:
        for chunk in response.iter_content(block_size):
            f.write(chunk)
            wrote += len(chunk)
            if progress_callback:
                progress = (wrote / total_size) * 50  # 50% progress for downloading
                progress_callback(progress)


def extract_zip(zip_path, destination_folder, progress_callback, status_label):
        
    """Extract ZIP file with progress updates."""
    if status_label:
        status_label("Extracting ZIP...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        total_files = len(zip_ref.filelist)
        for index, member in enumerate(zip_ref.filelist):
            zip_ref.extract(member, destination_folder)
            if progress_callback:
                progress = 50 + (index / total_files) * 50  # Remaining 50% progress for extraction
                progress_callback(progress)
                
                
def check_and_delete_path(path):
    if os.path.exists(path):
        if os.path.isfile(path):
            # Path is a file, so delete it
            try:
                os.remove(path)
                print(f"File '{os.path.basename(path)}' deleted successfully.")
            except OSError as e:
                print(f"Error: {path} : {e.strerror}")
        elif os.path.isdir(path):
            # Path is a directory, so delete it
            try:
                shutil.rmtree(path)
                print(f"Folder '{os.path.basename(path)}' deleted successfully.")
            except OSError as e:
                print(f"Error: {path} : {e.strerror}")
    else:
        print(f"Path '{path}' does not exist.")


