import tkinter as tk
from tkinter import messagebox
from localDB import db_utils
import re
from gui import gui

scheduler_window = None

"""settings page for setting up an automatic update schedule"""


def open_update_scheduler():
    global scheduler_window

    if scheduler_window is not None and tk.Toplevel.winfo_exists(scheduler_window):
        scheduler_window.lift()
        return

    scheduler_window = tk.Toplevel()
    scheduler_window.title("Update Settings")
    scheduler_window.iconbitmap(gui.ICON_FILE)
    scheduler_window.geometry("300x300")

    # Ensure the scheduler window closes with the main window
    def on_closing():
        global scheduler_window
        scheduler_window.destroy()
        scheduler_window = None

    scheduler_window.protocol("WM_DELETE_WINDOW", on_closing)

    # Read initial config
    config = db_utils.read_auto_update_config()
    auto_update = config.get('auto_update', False)
    schedule_time = config.get('schedule_time', '')

    # Buttons for automatic updates
    enable_button = tk.Button(scheduler_window, text="Enable Automatic Updates",
                              state='normal' if not auto_update else 'disabled',
                              command=lambda: toggle_auto_update(True, enable_button, disable_button, schedule_entry,
                                                                 schedule_button))
    enable_button.pack(pady=10)

    disable_button = tk.Button(scheduler_window, text="Disable Automatic Updates",
                               state='normal' if auto_update else 'disabled',
                               command=lambda: toggle_auto_update(False, enable_button, disable_button, schedule_entry,
                                                                  schedule_button))
    disable_button.pack(pady=10)

    # Label and Entry for schedule
    schedule_label = tk.Label(scheduler_window, text="Schedule Time (HH:MM):")
    schedule_label.pack(pady=5)

    schedule_entry = tk.Entry(scheduler_window)
    schedule_entry.pack(pady=5)
    schedule_entry.insert(0, schedule_time)
    schedule_entry.config(state='normal' if auto_update else 'disabled')

    # Button to confirm schedule
    schedule_button = tk.Button(scheduler_window, text="Set Schedule",
                                command=lambda: schedule_update(schedule_entry))
    schedule_button.pack(pady=20)
    schedule_button.config(state='normal' if auto_update else 'disabled')


def toggle_auto_update(enable, enable_button, disable_button, schedule_entry, schedule_button):
    config = db_utils.read_auto_update_config()
    config['auto_update'] = enable
    db_utils.write_auto_update_config(config)
    enable_button.config(state='disabled' if enable else 'normal')
    disable_button.config(state='normal' if enable else 'disabled')
    schedule_entry.config(state='normal' if enable else 'disabled')
    schedule_button.config(state='normal' if enable else 'disabled')


def schedule_update(schedule_entry):
    schedule_time = schedule_entry.get()
    if not re.match(r'^\d{2}:\d{2}$', schedule_time):
        messagebox.showerror("Invalid Time Format", "Please enter time in HH:MM format.")
        return

    config = db_utils.read_auto_update_config()
    config['schedule_time'] = schedule_time
    db_utils.write_auto_update_config(config)
    messagebox.showinfo("Schedule Update", f"Updates scheduled at: {schedule_time}")
