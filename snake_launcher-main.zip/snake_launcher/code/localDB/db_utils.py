from datetime import datetime
import json
import os
import uuid
from repo_utils import git_server
from filelock import FileLock

base_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
DIR_NAME = os.path.join(base_path, 'resources', 'DBfiles')

REPO_INFO = "repo_info.json"
SERVER_CONFIG = "server_config.json"
AUTO_UPDATE_CONFIG = "auto_update_config.json"

"""utils for getting and setting different data for different json files in an organized manner"""


class ServerConfig:
    """Class to hold the configuration for a server."""

    def __init__(self, uid, config_name, api_url, token, tool_list, last_updated):
        self.uid = uid
        self.name = config_name
        self.api_url = api_url
        self.token = token
        self.tool_list = tool_list
        self.last_updated = last_updated


def ensure_directory():
    """Ensure the directory for the JSON file exists."""
    os.makedirs(DIR_NAME, exist_ok=True)


def get_file_path(filename):
    return os.path.join(DIR_NAME, filename)


def read_json(filename):
    try:
        with FileLock(get_file_path(filename) + ".lock"):
            with open(get_file_path(filename)) as file:
                return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}  # Return an empty dictionary if the file does not exist


def write_json(data, filename):
    ensure_directory()
    try:
        with FileLock(get_file_path(filename) + ".lock"):
            with open(get_file_path(filename), "w") as file:
                json.dump(data, file)
    except (IOError, json.JSONDecodeError):
        return None


def delete_server_config(uid):
    __delete_entry(uid, SERVER_CONFIG)


def __delete_entry(key, filename):
    data = read_json(filename) or {}
    if key in data:
        del data[key]  # Remove the entry
        write_json(data, filename)  # Write the updated data back to the file
        print(f"Entry '{key}' deleted successfully.")
    else:
        print(f"No entry found for key: {key}")


def print_repo_info():
    current_data = read_json(REPO_INFO)
    print(json.dumps(current_data))


def print_server_config():
    current_data = read_json(SERVER_CONFIG)
    print(json.dumps(current_data))


def get_server_config(uid):
    data = read_json(SERVER_CONFIG)
    if uid in data:
        server_data = data[uid]
        return ServerConfig(uid, **server_data)
    else:
        return None


def add_or_update_server_config(uid=None, config_name="", api_url="", token="", tool_list=""):
    data = read_json(SERVER_CONFIG) or {}
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if not uid:
        uid = str(uuid.uuid4())  # Ensure a new UUID is generated only if not provided
    data[uid] = {
        'config_name': config_name,
        'api_url': api_url,
        'token': token,
        'tool_list': tool_list,
        'last_updated': now
    }
    write_json(data, SERVER_CONFIG)


def add_or_update_repo_info(repo, installed_version=None, pre_release=None, init=False):
    data = read_json(REPO_INFO) or []

    # Check if any dictionary has the specified repo_url
    for i, d in enumerate(data):
        if d['repo']['repo_url'] == repo['repo_url']:
            data[i]['repo'] = repo  # Update existing repository info
            if init is False:
                data[i]['installed_version'] = installed_version
                data[i]['pre_release'] = pre_release
            break
    else:
        d = dict()
        d['repo'] = repo
        d['installed_version'] = installed_version
        d['pre_release'] = pre_release
        data.append(d)  # If no existing repo found, add the new repo

    write_json(data, REPO_INFO)


def delete_repo_info(repo):
    data = read_json(REPO_INFO)

    data = remove_dict_by_key_value(data, 'repo_url', repo['repo']['repo_url'])

    write_json(data, REPO_INFO)


def remove_dict_by_key_value(my_list, key, value):
    return list(filter(lambda x: x.get(key) != value, my_list))


def get_all_server_configs():
    data = read_json(SERVER_CONFIG)
    servers = []
    for uid, server_data in data.items():
        server = ServerConfig(
            uid=uid,
            config_name=server_data['config_name'],
            api_url=server_data['api_url'],
            token=server_data['token'],
            tool_list=server_data['tool_list'],
            last_updated=server_data['last_updated']
        )
        servers.append(server)
    return servers


def check_tool_installation_required(repo, version, destination_folder="apps"):
    tool_path = os.path.join(destination_folder, repo['repo']['repo_name'])

    if check_subdirectory_with_prefix(tool_path):
        if get_installed_version(repo['repo']['repo_url']) == version:
            print(f'Version {version} of {repo['repo']['repo_name']} is already installed on the local machine!')
            return False
        else:
            print(f'{repo['repo']['repo_name']} is available but not at the required version.')
            return True
    else:
        print(f'{repo['repo']['repo_name']} is not available on the local machine.')
        return True


def check_subdirectory_with_prefix(tool_path):
    parent_dir = os.path.dirname(tool_path)
    prefix = os.path.basename(tool_path)
    for root, dirs, files in os.walk(parent_dir):
        for dir_name in dirs:
            if dir_name.startswith(prefix):
                return True
    return False


def get_installed_version(repo_url):
    data = read_json(REPO_INFO)
    for repo in data:
        if repo['repo']['repo_url'] == repo_url:
            return repo['installed_version']

    return None


def get_repo_info():
    return read_json(REPO_INFO)


def update_repo_info():
    servers = get_all_server_configs()
    repo_list = []
    for server in servers:
        repo_list.extend(git_server.get_list_from_git(server))

    for repo in repo_list:
        add_or_update_repo_info(repo, init=True)


def is_prerelease(repo_url, version):
    data = read_json(REPO_INFO)
    for repo in data:
        if repo['repo']['repo_url'] == repo_url:
            return repo['repo']['latest_prerelease'] == version

    return None


def get_pre_release(repo_url):
    data = read_json(REPO_INFO)
    for repo in data:
        if repo['repo']['repo_url'] == repo_url:
            return repo['pre_release']

    return None


def read_auto_update_config():
    return read_json(AUTO_UPDATE_CONFIG)


def write_auto_update_config(data):
    write_json(data, AUTO_UPDATE_CONFIG)
